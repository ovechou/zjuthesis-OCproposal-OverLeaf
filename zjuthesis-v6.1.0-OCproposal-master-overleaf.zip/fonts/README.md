# Setup fonts

You have to manually upload the fonts here.

Refer to this script for more help:
https://github.com/TheNetAdmin/zjuthesis/blob/master/script/ci/setup.sh

You need to download all the font files (.ttf/.ttc) mentioned in above script:
  - FangSong.ttf
  - TimesNewRoman.ttf
  - TimesNewRomanBold.ttf
  - TimesNewRomanItalic.ttf
  - TimesNewRomanBoldItalic.ttf
  - SimSun.ttc

Download these fonts to your local computer and upload them to this folder (fonts/).
